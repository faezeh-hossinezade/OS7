ln fafa1.sh fafa2.sh
ln -s fafa1.sh fafa3.sh
