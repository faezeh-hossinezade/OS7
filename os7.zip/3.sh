ln -i fafa1.sh fafa3.sh
ln -s fafa1.sh fafa2.sh
ln -P fafa1.sh fafa3.sh
