ln -s -r fafa1.sh fafa2.sh
